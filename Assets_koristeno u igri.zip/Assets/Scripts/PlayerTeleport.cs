using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerTeleport : MonoBehaviour
{
    private GameObject currentTeleporter;
    public AudioSource audioSorce;
    public AudioClip ZvukPortal;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Teleporter"))
        {
            currentTeleporter = collision.gameObject;
            transform.position = currentTeleporter.GetComponent<Teleporter>().GetDestination().position;
            audioSorce = GetComponent<AudioSource>();
            audioSorce.clip = ZvukPortal;
            audioSorce.Play();
        }
    }

}