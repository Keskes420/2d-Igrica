using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class PlayerMovement : MonoBehaviour
{
    private float horizontal;
    private float speed = 8f;
    private bool jump = false;
    private float jumpingPower = 16f;
    private bool isFacingRight = true;
    public Animator animator;
    public Text scoreText; 
    private static int score;
    public AudioSource audioSorce;
    public AudioClip Skok;
    public AudioClip ZvukNovcici;

    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;


    void Update()
    {
        //Kretanje
        horizontal = Input.GetAxisRaw("Horizontal");
        animator.SetFloat("Speed", Mathf.Abs(horizontal));
        audioSorce = GetComponent<AudioSource>();

        //skakanje
        if (Input.GetButtonDown("Jump") && IsGrounded())
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpingPower);
            audioSorce.clip = Skok;
            audioSorce.Play();
            animator.SetBool("Isjumping", true);
            jump = true;
        }else if (jump == true && IsGrounded() == true && rb.velocity.y < 0f)
        {
            animator.SetBool("Isjumping", false);
            jump = false;
        }

        if (Input.GetButtonUp("Jump") && rb.velocity.y > 0f)
        {
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * 0.5f);
        }
        
        Flip();
    }

    private void FixedUpdate()
    {
        rb.velocity = new Vector2(horizontal * speed, rb.velocity.y);
    }

    private bool IsGrounded()
    {
        return Physics2D.OverlapCircle(groundCheck.position, 0.2f, groundLayer);
    }
    
    //Okretanje
    private void Flip()
    {
        if (isFacingRight && horizontal < 0f || !isFacingRight && horizontal > 0f)
        {
            isFacingRight = !isFacingRight;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }


    //Zamke
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Trap"))
        {
            SceneManager.LoadScene("GameOver");
        }
    }

    //sakupljanje
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Coin")
        {
            audioSorce.clip = ZvukNovcici;
            audioSorce.Play();
            score++;
            scoreText.text = "Score: " + score;
            Destroy(collision.gameObject);
        }
        
    }
    
}