using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFake : MonoBehaviour
{
    public GameObject player;
    public float offset;
    public float offsetSmoothing;
    private Vector3 playerPosition;
    public float leftLimit;
    public float rightLimit;
    public float TopLimit;
    public float BottomLimit;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        playerPosition = new Vector3(player.transform.position.x, transform.position.y, transform.position.z);

        if (player.transform.localScale.x > 0f)
        {
            playerPosition = new Vector3(playerPosition.x + offset, playerPosition.y, playerPosition.z);
        }
        else
        {
            playerPosition = new Vector3(playerPosition.x - offset, playerPosition.y, playerPosition.z);
        }

        transform.position = Vector3.Lerp(transform.position, playerPosition, offsetSmoothing * Time.deltaTime);

        transform.position = new Vector3(Mathf.Clamp(transform.position.x, leftLimit, rightLimit), Mathf.Clamp(transform.position.y, BottomLimit, TopLimit), transform.position.z);

    }
    //crvene linije za rub do kuda moze kamera
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawLine(new Vector2(leftLimit, TopLimit), new Vector2(rightLimit, TopLimit));
        Gizmos.DrawLine(new Vector2(rightLimit, TopLimit), new Vector2(rightLimit, BottomLimit));
        Gizmos.DrawLine(new Vector2(rightLimit, BottomLimit), new Vector2(leftLimit, BottomLimit));
        Gizmos.DrawLine(new Vector2(leftLimit, BottomLimit), new Vector2(leftLimit, TopLimit));
    }
}