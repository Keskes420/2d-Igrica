using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour
{
    public float timeRemaining = 10;
    public bool timerIsRunning = false;
    public Text timeText;
    public AudioSource audioSorce;
    public AudioClip Vrijeme;

    private void Start()
    {
        audioSorce = GetComponent<AudioSource>();
        // Starts the timer automatically
        timerIsRunning = true;
        switch (GameValues.Difficulty)
        {
            case GameValues.Difficulties.Easy:
                timeRemaining = 60;
                break;
            case GameValues.Difficulties.Medium:
                timeRemaining = 30;
                break;
            case GameValues.Difficulties.Hard:
                timeRemaining = 15;
                break;
        }
    }
    void Update()
    {
        if (timerIsRunning)
        {
            if (timeRemaining > 0)
            {
                timeRemaining -= Time.deltaTime;
                DisplayTime(timeRemaining);
            }

            else
            {
                Debug.Log("Time has run out!");
                timeRemaining = 0;
                timerIsRunning = false;
                SceneManager.LoadScene("TimeOutMeni");
            }
        }
    }
    void DisplayTime(float timeToDisplay)
    {
        timeToDisplay += 1; 
        float seconds = Mathf.FloorToInt(timeToDisplay);
        timeText.text = string.Format("{000}", seconds);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Time")
        {
            audioSorce.clip = Vrijeme;
            audioSorce.Play();
            timeRemaining = timeRemaining + 4;
            Destroy(collision.gameObject);
        }
    }
}